
public interface KhachSan {
	public void  datPhong(KhachHang khachHang) ;
	public  void datDichVu(KhachHang khachHang);
	public  void themDichVu( DichVu dichVu);

}
