
public class DatPhongThuong implements KhachSan  {

}
