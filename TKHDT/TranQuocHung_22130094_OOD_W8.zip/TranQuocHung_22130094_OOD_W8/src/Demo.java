import java.util.ArrayList;
import java.util.List;

public class Demo {
	KhachSan khachSan = new KhachSan() {
	};
	List<KhachHang> dsKhachHangs = new ArrayList<KhachHang>();
	
	

}
