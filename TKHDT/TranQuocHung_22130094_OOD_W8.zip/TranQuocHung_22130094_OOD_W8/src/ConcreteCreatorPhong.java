
public class ConcreteCreatorPhong implements CreatorPhong {

	@Override
	public ProductPhong taoPhong() {
		
		return null;
	}

}
