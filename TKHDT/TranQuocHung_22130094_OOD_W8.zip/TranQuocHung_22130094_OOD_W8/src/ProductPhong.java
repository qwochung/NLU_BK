
public abstract class ProductPhong {
	int maPhong;
	int soLuongKhach;
	int giaPhong;
	
	
	
	
	

}
