
public class ProductPhongThuong extends ProductPhong{
	

	

}
