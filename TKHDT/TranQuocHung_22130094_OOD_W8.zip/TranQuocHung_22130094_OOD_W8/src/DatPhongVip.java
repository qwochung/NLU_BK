
public class DatPhongVip implements KhachSan {

	@Override
	public void datPhong(KhachHang khachHang) {
		CreatorPhong
		
	}

	
	
	
	
	@Override
	public void datDichVu(KhachHang khachHang) {
		
	}

	@Override
	public void themDichVu(DichVu dichVu) {
		
	}

}
