
public interface CreatorPhong {
	public ProductPhong taoPhong();
	

}
