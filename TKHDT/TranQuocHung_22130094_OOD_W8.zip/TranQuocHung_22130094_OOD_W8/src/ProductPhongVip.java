
public class ProductPhongVip extends ProductPhong{

}
