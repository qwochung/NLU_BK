	
public interface Point {

}
