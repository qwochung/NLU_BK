
public class Credit implements PaymentType {

	@Override
	public int discount(int bill) {
		// TODO Auto-generated method stub
		return 5;
	}
	
}
