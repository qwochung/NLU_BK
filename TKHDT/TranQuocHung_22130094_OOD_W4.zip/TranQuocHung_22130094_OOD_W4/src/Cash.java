
public abstract class  Cash implements PaymentType{
	Point point ;
	
	public abstract int discount(int bill);

}
