
public class Point_Under_1M implements Point {
	int p = 5;

	public Point_Under_1M(int p) {
		super();
		this.p = p;
	}

	int getP() {
		return p;
	}

	
	
}
