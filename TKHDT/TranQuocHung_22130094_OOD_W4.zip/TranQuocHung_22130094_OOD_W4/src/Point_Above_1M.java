
public class Point_Above_1M {
	int p = 10;

	public Point_Above_1M(int p) {
		super();
		this.p = p;
	}

	int getP() {
		return p;
	}
	
	

	
	
}
