
public class Cash_Under_1M extends Cash {

	@Override
	public int discount(int bill) {
		// TODO Auto-generated method stub
		return bill - bill*10/100  ;
	}

}
