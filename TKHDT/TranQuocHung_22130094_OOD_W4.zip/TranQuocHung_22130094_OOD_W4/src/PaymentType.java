
public interface PaymentType {
	public int discount(int bill);
}
