import java.util.List;

public class Store {
	List<Customer> customers; 

}
