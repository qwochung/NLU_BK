import java.time.LocalDate;
import java.util.List;

public class Customer_Cash_Under extends Customer {

	public Customer_Cash_Under(int id, String name, LocalDate birthD, Point point, List<Product> products,
			PaymentType type) {
		super(id, name, birthD, point, products, type);
		// TODO Auto-generated constructor stub
	}
	public Customer_Cash_Under( int bill) {
		PaymentType type = new Cash_Under_1M();
		point = (Point) new Point_Under_1M(bill);
		
		
		
		
	}
	
	

}
