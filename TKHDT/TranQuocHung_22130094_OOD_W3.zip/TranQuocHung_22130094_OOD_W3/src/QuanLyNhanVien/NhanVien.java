package QuanLyNhanVien;

import java.time.LocalDate;

public class NhanVien {
	
	String maNV, tenNV;
	boolean nu;
	LocalDate ngaySinh; 
	double luongCB;
	LocalDate ngayVaoLam;
	LoaiNV loaiNV;

}
