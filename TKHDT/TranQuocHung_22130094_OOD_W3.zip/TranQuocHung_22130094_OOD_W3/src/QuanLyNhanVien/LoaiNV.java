package QuanLyNhanVien;

public class LoaiNV {

}
