package Singelton;

public class Test {
	

}
