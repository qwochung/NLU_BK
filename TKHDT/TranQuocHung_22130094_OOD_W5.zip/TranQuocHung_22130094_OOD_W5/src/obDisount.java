
public interface obDisount {
	public void updateDiscount( String name, String message) ;

}
