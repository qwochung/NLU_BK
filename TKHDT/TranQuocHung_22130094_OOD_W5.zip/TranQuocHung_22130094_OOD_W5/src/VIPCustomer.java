import java.time.LocalDate;
import java.util.List;

public class VIPCustomer extends Customer implements obDisount, obProduct {
	int point;

	public VIPCustomer(int id, String name, LocalDate birth, int phone, List<Product> listProducts) {
		super(id, name, birth, phone, listProducts);
		point = 50;
	}

	@Override
	public void updateProduct(String name, String message) {
		System.out.println(phone+ " " + name + " " + message);
		
	}

	@Override
	public void updateDiscount(String name, String message) {
		System.out.println(phone+ " " +name + " " + message);
		
	}
	
}
