
public interface obProduct {
	public void updateProduct( String name, String message) ;

}
