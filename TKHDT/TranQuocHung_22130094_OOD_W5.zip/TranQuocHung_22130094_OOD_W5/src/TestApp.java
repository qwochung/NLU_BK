import java.time.LocalDate;

public class TestApp {
	
	
	public static void main(String[] args) {
		
		
		
		
		obProduct p1 = new NomalCustomer(11, "Jhin", LocalDate.of(2013, 12, 23) , 113, null);
		obDisount d1 = new VIPCustomer(11, "Tim", LocalDate.of(2013, 12, 23) , 113, null);
		
		
		Store store = new Store("Cong Ty abc ", "", "");
		store.registerProdut(p1);
		store.registerDiscount(d1);
		store.setInforProduct("new inffor  of product");
		store.setInforDiscount("new inffor  of discount");
		
		
	}

}
