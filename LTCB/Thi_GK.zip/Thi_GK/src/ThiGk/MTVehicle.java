package ThiGk;

public class MTVehicle implements Ivehicle {

	@Override
	public String toString() {
		return "emty" ;
	}
	

}
