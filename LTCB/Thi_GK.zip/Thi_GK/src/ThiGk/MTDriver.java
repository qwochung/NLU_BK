package ThiGk;

public class MTDriver implements IDriver {
	

}
