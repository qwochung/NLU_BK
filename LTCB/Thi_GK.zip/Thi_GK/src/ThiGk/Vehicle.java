package ThiGk;

public class Vehicle {
	int iid ;
	String vehicleName;
	int year;
	/**
	 * @param iid
	 * @param vehicleName
	 * @param year
	 */
	public Vehicle(int iid, String vehicleName, int year) {
		super();
		this.iid = iid;
		this.vehicleName = vehicleName;
		this.year = year;
	}
	@Override
	public String toString() {
		return this.iid + " " + this.vehicleName+ " " + this.year ;
	}
	

	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
}
