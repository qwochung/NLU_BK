package ThiGk;

public interface  IDriver {
}
