package ThiGk;

public interface Ivehicle {
	

}
