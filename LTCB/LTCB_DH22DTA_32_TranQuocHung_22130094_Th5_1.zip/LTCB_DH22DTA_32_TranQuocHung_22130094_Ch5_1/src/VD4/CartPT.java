package VD4;

public class CartPT {
	int x,y;

	/**
	 * @param x
	 * @param y
	 */
	public CartPT(int x, int y) {
		super();
		this.x = x;
		this.y = y;
	}

	@Override
	public String toString() {
		return " -- CartPT : x=" + x + ", y=" + y  ;
	}
}
