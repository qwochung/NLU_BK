package VD4;

public   interface Shape {

}
