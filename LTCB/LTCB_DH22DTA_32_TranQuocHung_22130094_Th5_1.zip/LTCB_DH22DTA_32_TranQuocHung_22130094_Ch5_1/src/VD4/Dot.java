package VD4;

public class Dot extends ASingleShape {

	public Dot(CartPT location) {
		super(location);
		// TODO Auto-generated constructor stub
	}

	@Override
	public String toString() {
		return "Dot " + this.location.toString();
	}
	

}
