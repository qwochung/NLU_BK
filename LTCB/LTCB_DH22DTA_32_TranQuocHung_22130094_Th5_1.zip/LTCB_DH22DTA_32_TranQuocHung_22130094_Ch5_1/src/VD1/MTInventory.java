/**
 * 
 */
package VD1;

/**
 * @author ADMIN
 *
 */
public class MTInventory implements Inventory {

	@Override
	public String toString() {
		return " ";
	}

}


