package VD1;

public interface Inventory {

}
