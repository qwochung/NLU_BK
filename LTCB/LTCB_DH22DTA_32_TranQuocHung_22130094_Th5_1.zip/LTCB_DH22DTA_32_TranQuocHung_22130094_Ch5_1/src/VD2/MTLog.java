package VD2;

public class MTLog implements ILog {

	@Override
	public String toString() {
		return " ";
	}

}
