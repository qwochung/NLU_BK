package VD2;

public interface  ILog {

}
