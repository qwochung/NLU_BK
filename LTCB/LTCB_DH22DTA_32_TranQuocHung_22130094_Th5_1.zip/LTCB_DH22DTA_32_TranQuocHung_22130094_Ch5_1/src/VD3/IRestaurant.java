package VD3;

public interface  IRestaurant {

}
