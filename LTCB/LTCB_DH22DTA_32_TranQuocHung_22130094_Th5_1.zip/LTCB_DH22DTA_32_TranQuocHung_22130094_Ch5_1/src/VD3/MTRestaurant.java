package VD3;

public class MTRestaurant implements IRestaurant {

	@Override
	public String toString() {
		return " ";
	}
	

}
