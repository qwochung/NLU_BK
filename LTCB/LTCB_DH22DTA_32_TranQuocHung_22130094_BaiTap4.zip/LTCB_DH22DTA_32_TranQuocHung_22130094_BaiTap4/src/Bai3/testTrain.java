/**
 * 
 */
package Bai3;

import junit.framework.TestCase;

/**
 * @author ADMIN
 *
 */
public class testTrain  extends TestCase{
	
	public void testConstructer() {
		 new Bus(40, 60, "Suoi Tien", "Q.2", 7000);
		 new Car(4, 80, "KIA", 2020, 2022);
		new Limos(24, 100, 12, null, "Good");
		
		
	}

}
