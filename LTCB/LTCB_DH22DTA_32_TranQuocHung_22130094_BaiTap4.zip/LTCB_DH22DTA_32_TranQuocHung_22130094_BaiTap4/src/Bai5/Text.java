/**
 * 
 */
package Bai5;

/**
 * @author ADMIN
 *
 */
public class Text extends Gallery {
	int nLine;

	/**
	 * @param src
	 * @param size
	 * @param nLine
	 */
	public Text(String name, int size, int nLine) {
		super(name, size);
		this.nLine = nLine;
	}

}
