/**
 * 
 */
package Bai8;

/**
 * @author ADMIN
 *
 */
public class HardcoverBooks extends RecordBook {

	/**
	 * @param title
	 * @param authorName
	 * @param price
	 * @param publicationYear
	 * @param discount
	 */
	public HardcoverBooks(String title, String authorName, double price, int publicationYear, double discount) {
		super(title, authorName, price, publicationYear, discount);
		// TODO Auto-generated constructor stub
	}
	
	

	
	
	
	

}
