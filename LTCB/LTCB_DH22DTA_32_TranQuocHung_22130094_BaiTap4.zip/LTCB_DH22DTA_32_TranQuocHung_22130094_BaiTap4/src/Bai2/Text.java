/**
 * 
 */
package Bai2;

/**
 * @author ADMIN
 *
 */
public class Text extends Gallery {
	int nLine;

	/**
	 * @param src
	 * @param size
	 * @param nLine
	 */
	public Text(String src, int size, int nLine) {
		super(src, size);
		this.nLine = nLine;
	}

}
