/**
 * 
 */
package Bai1;

/**
 * @author ADMIN
 *
 */
public class checkingAccount extends typeAccount {
	double minBalance;

	/**
	 * @param id
	 * @param name
	 * @param currentBalance
	 * @param minBalance
	 */
	public checkingAccount(int id, String name, double currentBalance, double minBalance) {
		super(id, name, currentBalance);
		this.minBalance = minBalance;
	}


	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
		
}
