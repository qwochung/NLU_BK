package Bai1;

import junit.framework.TestCase;

public class testBankAccount extends TestCase	 {
	
	// Testing for bankAccount
	
	public void testConstructer () {
		new CDAccount(111, "Quoc Hung", 10000.0, 0.7, 10);
	}
	

	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
}
