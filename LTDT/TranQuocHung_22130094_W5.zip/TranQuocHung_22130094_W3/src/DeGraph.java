

public class DeGraph extends Graph{

	public DeGraph() {
		super();
	}
	
	public boolean checkUnGraph() {
		for (int i = 0; i < matrix.length; i++) {
			for (int j = 0; j < matrix.length; j++) {
				if (i==j ) {
					break;
				}
			
				if (matrix[i][j] == matrix[j][i]) {
					System.out.println("Không phải đồ thị vô hướng.");
					return false;
				}
				
			
			}
		}
		System.out.println("Đồ thị có hướng.");
		return true;
		
	}

	
	@Override
	public int sumDeg() {
		int vertices = matrix.length;
        int totalDegree = 0;

        for (int i = 0; i < vertices; i++) {
            int inDegree = 0;
            int outDegree = 0;
 
            for (int j = 0; j < vertices; j++) {
                inDegree += matrix[j][i]; // In-degree
                outDegree += matrix[i][j]; // Out-degree
            }

            totalDegree += inDegree + outDegree;
        }

        return totalDegree;
	}
	
	
	@Override
	public int numEdges() {
		return sumDeg()/2;
	}
	

	
	
	
	@Override
	public void checkEuler() {
		if (checkConnect()) {
			
			
		}
		
		else {
			System.out.println("Đồ thị ko liên thông, ko xét đường đi.");
		}
		
	}



}
