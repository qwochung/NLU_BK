import java.io.IOException;
import java.util.Arrays;

public class UnGraph extends Graph {
	

	public UnGraph() {
		super();
	}
	
	
	
	
//	Check Ungraph
	@Override
	public boolean checkUnGraph() {
		for (int i = 0; i < matrix.length; i++) {
			for (int j = 0; j < matrix.length; j++) {
				if (i==j ) {
					break;
				}
			
				if (matrix[i][j] != matrix[j][i]) {
					System.out.println("Không phải đồ thị vô hướng.");
					return false;
				}
				
			
			}
		}
		System.out.println("Đồ thị vô hướng.");
		return true;
		
	}
	
	
	
	
	@Override

	public int sumDeg() {
		int resutt = 0;
		for (int[] is : matrix) {
			resutt += Arrays.stream(is).sum();
		}
		return resutt;
	}
	
	
//	numEdges 
	@Override
	public int numEdges() {
		return sumDeg()/2;
	}
	
	
	
	@Override
	public void checkEuler() {
		if (checkConnect()) {
			int count = 0;
			for (int i = 0; i < matrix.length; i++) {
				if (Arrays.stream(matrix[i]).mapToDouble(x-> x).sum() %2 !=0 ) {
					count++;
				}
				
			}
			
			if (count == 2) {
				System.out.println("Đồ thị chỉ có đường đi");
			}
			
			if (count == 0) {
				System.out.println("Đồ thị có chu trình.");
			}
			
			else {
				System.out.println("KO có đường đi và chu trình.");
			}
			
				
		}
		else {
			System.out.println("Đồ thị ko liên thông, ko xét đường đi.");
		}
	}
	
	public static void main(String[] args) throws NumberFormatException, IOException {
		Graph graph = new UnGraph() ;

//		graph.loadGraph("test3.txt");
//		graph.loadGraph("luongphan.txt");
		if (graph.loadGraph("euler.txt") == true) {
			
			graph.printMatrix();
			System.out.println("Đồ thị có hợp lí ko ? " + graph.checkValid());
			
			graph.checkUnGraph();  // Kiểm tra đồ thị có hướng ko ?
			
			System.out.println("Tổng bậc của đỉnh đã cho là : " + graph.deg(3));
			
			System.out.println("Tổng bậc của đồ thị là : " + graph.sumDeg());
			
			System.out.println("Tổng cạnh của đồ thị : " + graph.numEdges());
			
			System.out.println("BFS : " + Arrays.toString(graph.BFSGraph()));

			System.out.println("DFS : " + Arrays.toString(graph.DFSGraph()));
			
			System.out.println("BFS input vex : " + Arrays.toString(graph.BFSGraph(2)));
			
			System.out.println("DFS input vex : " + Arrays.toString(graph.DFSGraph(2)));
			
			System.out.println("checkConnect : " + graph.checkConnect());
			
			System.out.println("countConnect : " + graph.countConnect());
			
			System.out.print("Các đỉnh liên thông là 			 ");		graph.diTimCacDinhLienThong();
			
			System.out.print("Kiểm tra tính liên thông bằng thuật toán BFS thì ");		graph.isConnected();
	
			System.out.print("Đường đi từ A đến B là : ");			graph.findPathTwoVexs(3, 0);
	
			System.out.println("Kiểm tra tính lưỡng phân  : " + graph.checkBipartiteGraph());  // chưa đúng !
			
			System.out.print("Kiểm tra đồ thị có Euler không ? : ");		graph.checkEuler();
			
		}
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		






		
		
	}




	





	
}
