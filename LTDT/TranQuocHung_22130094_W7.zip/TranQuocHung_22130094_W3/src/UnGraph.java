import java.io.IOException;
import java.util.Arrays;
import java.util.LinkedList;
import java.util.Queue;
import java.util.Stack;


public class UnGraph extends Graph {
	

	public UnGraph() {
		super();
	}
	
	
	
	
//	Check Ungraph
	@Override
	public boolean checkUnGraph() {
		for (int i = 0; i < matrix.length; i++) {
			for (int j = 0; j < matrix.length; j++) {
				if (i==j ) {
					break;
				}
			
				if (matrix[i][j] != matrix[j][i]) {
					System.out.println("Không phải đồ thị vô hướng.");
					return false;
				}
				
			
			}
		}
		System.out.println("Đồ thị vô hướng.");
		return true;
		
	}
	
	
	
	
	@Override
//sumDeg
	public int sumDeg() {
		int resutt = 0;
		for (int[] is : matrix) {
			resutt += Arrays.stream(is).sum();
		}
		return resutt;
	}
	
	
//	numEdges 
	@Override
	public int numEdges() {
		return sumDeg()/2;
	}
	
	
	

	@Override
	public boolean checkStrongConnect() {
		System.out.println("Đồ thị vô hướng! ");
		return false;
	}



	
	
	
	
	
//	checkEuler
	@Override
	public void checkEuler() {
		if (checkConnect()) {
			int count = 0;
			for (int i = 0; i < matrix.length; i++) {
				if (Arrays.stream(matrix[i]).mapToDouble(x-> x).sum() %2 !=0 ) {
					count++;
				}
				
			}
			
			if (count == 2) {
				System.out.println("Đồ thị chỉ có đường đi");
			}
			
			if (count == 0) {
				System.out.println("Đồ thị có chu trình.");
			}
			
			else {
				System.out.println("KO có đường đi và chu trình.");
			}
			
				
		}
		else {
			System.out.println("Đồ thị ko liên thông, ko xét đường đi.");
		}
	}
	
//	isEulerGraph
	public  boolean isEulerGraph() {
		if (checkConnect()) {
			int count = 0;
			for (int i = 0; i < matrix.length; i++) {
				if (Arrays.stream(matrix[i]).mapToDouble(x-> x).sum() %2 !=0 ) {
					count++;
				}
			}
			if (count == 0) {
				return true;
			}
			else {
				return false;
			}
			
 		}
		
		return false;
		

		
	}
	
	

//	isHalfEulerGraph
	@Override
	public boolean isHalfEulerGraph() {
		if (checkConnect()) {
			int count = 0;
			for (int i = 0; i < matrix.length; i++) {
				if (Arrays.stream(matrix[i]).mapToDouble(x-> x).sum() %2 !=0 ) {
					count++;
				}
			}
			if (count == 2 ) {
				return true;
			}
			else {
				return false;
			}
			
 		}
		else {
			return false;
		}
	}


	
//	findEulerCycle
	public void findEulerCycle() {
		if (checkDeg()) {
			System.out.print( "Đồ thị có chu trình Euler là : ");
			int[][] subMatrix = deepCopy();

			Stack<Integer> previous = new Stack<Integer>();
//			Stack<Integer> CE = new Stack<Integer>();
			Queue<Integer> CE = new LinkedList<Integer>();
			int current = 0;
			previous.add(current);
			while (!previous.isEmpty()) {
				for (int i = 0; i < subMatrix.length; i++) {
					if (subMatrix[current][i] != 0 || subMatrix[i][current] != 0) {
						subMatrix[current][i] = 0;
						subMatrix[i][current] = 0;
						previous.add(current);
						current = i;
						
						break;
					}

				}
				if (!checkNext(current, subMatrix)) {
					CE.add(current);
					current = previous.pop();
				}
				

			}
//			System.out.print(CE.toString());
			int size = CE.size();
			for (int i = 0; i <size; i++) {
				System.out.print( " "+CE.poll());
				
			}
			
		} 
		else {
			System.out.println("Ko có chu trình euler");
		}
	}
	

	
	
//	sub menthod for findEulerCycle
	private boolean checkDeg() {
		if (checkConnect()) {
			int count = 0;
			for (int i = 0; i < matrix.length; i++) {
				if (Arrays.stream(matrix[i]).mapToDouble(x -> x).sum() % 2 != 0) {
					count++;
			}
		}
		return count == 0 ? true : false;
		}
		else {
			return false;
		}
		

	}
	
	



//	findEulerPath
	@Override
	public void findEulerPath() {
		if (isEulerGraph()) {
			System.out.println("Vì có chu trình nên có đường đi Euler ");
			findEulerCycle();
		} else {

			if (isHalfEulerGraph()) {
				System.out.print("Đồ thị có đường đi Euler là : ");
				int[][] subMatrix = deepCopy();

				Stack<Integer> previous = new Stack<Integer>();
				Stack<Integer> CE = new Stack<Integer>();
				int current = 0;

				// find start peak
				for (int i = 0; i < subMatrix.length; i++) {
					if (Arrays.stream(matrix[i]).sum() % 2 != 0) {
						current = i;
						break;
					}
				}

				previous.add(current);
				while (!previous.isEmpty()) {
					for (int i = 0; i < subMatrix.length; i++) {
						if (subMatrix[current][i] != 0 || subMatrix[i][current] != 0) {
							subMatrix[current][i] = 0;
							subMatrix[i][current] = 0;
							previous.add(current);
							current = i;

							break;
						}

					}
					if (!checkNext(current, subMatrix)) {
						CE.add(current);
						current = previous.pop();
					}

				}
				System.out.print(CE.toString());

			} else {
				System.out.println("Ko có Euler");
			}
		}

	}
	
	
	
	
	
	
	
	@Override
	public int[][] SpanningTreeByDFS() {
//		Sử dụng đệ qui
		int vertrex = 0;
		int [][] result = new int [matrix.length][matrix.length];
		daTham = new boolean[matrix.length];
		
		
		
		daTham[vertrex] = true;
		recursive(vertrex, result, daTham);
		return result;
	}
	
	
	public void recursive(int vertrex , int [][] result , boolean[] datham) {
		if (vertrex > matrix.length) {
			return;
		}
		
		
		else {
			for (int i = 0; i < result.length; i++) {
				if (matrix[vertrex][i] != 0 && !datham[i]) {
					datham[i] = true;
					result[vertrex][i] = 1;
					result[i][vertrex] = 1;
					recursive(i, result, datham);
				}
				
			}
			
			
		}
		
		
	}
	
	
	
//	Không sử dụng đệ qui
	public  int[][] SpanningTreeByDFS(int v ){
		
		
		Stack<Integer> stack = new Stack<Integer>();
		int vertrex = 0;
		int [][] result = new int [matrix.length][matrix.length];
		daTham = new boolean[matrix.length];
		
		stack.add(vertrex);
		daTham[vertrex] = true;
		
		while (!stack.isEmpty()) {
			vertrex = stack.pop();
			for (int i = 0; i < result.length; i++) {
				if (matrix[vertrex][i] != 0 && !daTham[i]) {
					stack.push(i);
					daTham[i] = true;
					result[vertrex][i] = 1;
					result[i][vertrex] = 1;
				}
				
			}
			
			
		}
		
		
		
		
		return result;
		
	}
	
	
	@Override
	public int[][] SpanningTreeByBFS() {
		Queue<Integer> next = new LinkedList<Integer>();
		daTham = new boolean[matrix.length];
		int [][] result = new int[matrix.length][matrix.length];
		
		int vertrex = 0;
		next.add(vertrex);
		daTham[vertrex] = true;
		
		while (!next.isEmpty()) {
			vertrex = next.poll();
			for (int i = 0; i < matrix.length; i++) {
				if (matrix[vertrex][i] != 0 && !daTham[i]) {
					
					result[vertrex][i] = 1;
					result[i][vertrex] = 1;
					daTham[i] = true;
					next.add(i);
				}
				
			}
			
		}
		
		return  result;
	}
	
	
	
	
	
	public static void main(String[] args) throws NumberFormatException, IOException {
		Graph graph = new UnGraph() ;

//		graph.loadGraph("test3.txt");
//		graph.loadGraph("luongphan.txt");
//		if (graph.loadGraph("eulerpath.txt") == true) {
			if (graph.loadGraph("Cay_Bao_Trum.txt") == true) {
			
			graph.printMatrix();
			System.out.println("Đồ thị có hợp lí ko ? " + graph.checkValid());
			
			graph.checkUnGraph();  // Kiểm tra đồ thị có hướng ko ?
			
			System.out.println("Tổng bậc của đỉnh đã cho là : " + graph.deg(3));
			
			System.out.println("Tổng bậc của đồ thị là : " + graph.sumDeg());
			
			System.out.println("Tổng cạnh của đồ thị : " + graph.numEdges());
			
			System.out.println("BFS : " + Arrays.toString(graph.BFSGraph()));

			System.out.println("DFS : " + Arrays.toString(graph.DFSGraph()));
			
			System.out.println("BFS input vex : " + Arrays.toString(graph.BFSGraph(2)));
			
			System.out.println("DFS input vex : " + Arrays.toString(graph.DFSGraph(2)));
			
			System.out.println("checkConnect : " + graph.checkConnect());
			
			System.out.println("countConnect : " + graph.countConnect());
			
			System.out.print("Các đỉnh liên thông là 			 ");		graph.diTimCacDinhLienThong();
			
			System.out.print("Kiểm tra tính liên thông bằng thuật toán BFS thì ");		graph.isConnected();
	
			System.out.print("Đường đi từ A đến B là : ");			graph.findPathTwoVexs(3, 0);
	
			System.out.println("Kiểm tra tính lưỡng phân  : " + graph.checkBipartiteGraph());  
			
			System.out.print("Kiểm tra đồ thị có Euler không ? : ");		graph.checkEuler();
			
			System.out.println("Kiểm tra đồ thị có chu trình Euler không ? : " + graph.isEulerGraph() );		
			
			System.out.println("Kiểm tra đồ thị có dường đi Euler không ? : " + graph.isEulerGraph() );		
			 
			graph.findEulerCycle(); // Tìm chu trình Euler
			graph.printMatrix();
			
			graph.findEulerPath(); // Tìm đường đi Euler
			
			System.out.println("Kiểm tra lưỡng phần bằng BFS: " + graph.checkBipartiteGraphWithBFS());
			
			System.out.println("Đường đi Hamilton:  " );
			graph.findHamiltionCycle();
			
			graph.color();

			System.out.println("===================Cây bao trùm duyệt theo chiều rộng BFS=========================================" );
			graph.printMatrix(graph.SpanningTreeByBFS());
			
			
			System.out.println("\n\n===================Cây bao trùm duyệt theo chiều sâu DFS sử dụng đệ qui =========================================" );
			graph.printMatrix(graph.SpanningTreeByDFS());
			
			
			
			System.out.println("\n\n===================Cây bao trùm duyệt theo chiều sâu DFS KHÔNG sử dụng đệ qui =========================================" );
			graph.printMatrix(graph.SpanningTreeByDFS(0));
			
		
		}
		
		
		
		
		

		
		
	}




	




	










	





	
}
