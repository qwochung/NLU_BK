import java.io.IOException;
import java.util.Arrays;
import java.util.Stack;

public class DeGraph extends Graph{

	public DeGraph() {
		super();
	}
	
//	checkUnGraph
	public boolean checkUnGraph() {
		for (int i = 0; i < matrix.length; i++) {
			for (int j = 0; j < matrix.length; j++) {
				if (i==j ) {
					break;
				}
			
				if (matrix[i][j] == matrix[j][i] &&  matrix[j][i] != 0) {
					System.out.println("Không phải đồ thị có hướng.");
					return false;
				}
				
			
			}
		}
		System.out.println("Đồ thị có hướng.");
		return true;
		
	}

	
	
//	sumDeg
	@Override
	public int sumDeg() {
		int vertices = matrix.length;
        int totalDegree = 0;

        for (int i = 0; i < vertices; i++) {
            int inDegree = 0;
            int outDegree = 0;
 
            for (int j = 0; j < vertices; j++) {
                inDegree += matrix[j][i]; // In-degree
                outDegree += matrix[i][j]; // Out-degree
            }

            totalDegree += inDegree + outDegree;
        }

        return totalDegree;
	}
	
//	numEdges
	@Override
	public int numEdges() {
		return sumDeg()/2;
	}
	


	@Override
	public boolean checkStrongConnect() {
		if (checkConnect()) {

			for (int i = 0; i < matrix.length; i++) {
				int inDegree = 0;
				int outDegree = 0;
				for (int j = 0; j < matrix.length; j++) {
					inDegree += matrix[i][j];
					outDegree += matrix[j][i];

				}
				if (inDegree != outDegree) {
//					System.out.println("Đồ thị liên thông yếu!");
					return false;
				}

			}
//			System.out.println("Đồ thị liên thông mạnh!");
			return true;

		}
		else {
			throw new IllegalArgumentException("Ko phải là đồ thị vô hướng, ko xét được tính mạnh yếu.");
		}
		
		
	}
	
	


	
	@Override
	public void checkEuler() {
		if (checkConnect()) {
			int inDegree = 0;
			int outDegree = 0;
			for (int i = 0; i < matrix.length; i++) {
				
				for (int j = 0; j < matrix.length; j++) {
					inDegree += matrix[i][j];
					outDegree += matrix[j][i];

				}
				if (inDegree != outDegree) {
					System.out.println("Đồ thị liên thông yếu!");
					break;
				}

			}
			if (inDegree == outDegree) {
			System.out.println("Đồ thị liên thông mạnh!");
			}
		}
		else {
			throw new IllegalArgumentException("Ko phải là đồ thị vô hướng, ko xét được tính mạnh yếu.");
		}
		
		
	}

	
//	isEulerGraph
	@Override
	public boolean isEulerGraph() {
		if (checkStrongConnect()) {
			return true;
		}
		
		else {
			return false;
		}
	}
	


	
//	isHalfEulerGraph
	@Override
	public boolean isHalfEulerGraph() {
		if (isEulerGraph()) {
			return true;
		}
		
		if (!checkStrongConnect()) {
			return true;
		}
		
		else {
			return false;
		}
	}

	
//	findEulerCycle
	@Override
	public void findEulerCycle() {
		if (isEulerGraph()) {
			System.out.print( "Đồ thị có chu trình Euler là : ");
			int[][] subMatrix = deepCopy();

			Stack<Integer> previous = new Stack<Integer>();
			Stack<Integer> CE = new Stack<Integer>();
//			Queue<Integer> CE = new LinkedList<Integer>();
			int current = 0;
			previous.add(current);
			while (!previous.isEmpty()) {
				for (int i = 0; i < subMatrix.length; i++) {
					if (subMatrix[current][i] != 0 ) {
						subMatrix[current][i] = 0;
						previous.add(current);
						current = i;
						
						break;
					}

				}
				if (!checkNext(current, subMatrix)) {
					CE.add(current);
					current = previous.pop();
				}
				

			}
			int size = CE.size();
			for (int i = 0; i <size; i++) {
				System.out.print( " "+CE.pop());
				
			}
		}
		else {
			System.out.println("Không có chu trình Euler ");
		}
		
	}

	
//	findEulerPath
	@Override
	public void findEulerPath() {
		if (isEulerGraph()) {
			System.out.println("Vì có chu trình Euler nên có đường đi Euler.");
			findEulerCycle();
		}
		else {
			if (isHalfEulerGraph()) {
				System.out.print( "Đồ thị có đường đi Euler là : ");
				int[][] subMatrix = deepCopy();
				int current = 0;
				Stack<Integer> previous = new Stack<Integer>();
				Stack<Integer> CE = new Stack<Integer>();
//				Queue<Integer> CE = new LinkedList<Integer>();
				
//				Tìm đỉnh deg- != deg+
				for (int i = 0; i < subMatrix.length; i++) {
					int inDegree = 0;
					int outDegree = 0;
					for (int j = 0; j < subMatrix.length; j++) {
						inDegree += matrix[i][j];
						outDegree += matrix[j][i];
						
					}
					if (inDegree != outDegree  && inDegree>outDegree) {
						current = i;
						break;
					}
					
				}
				
				
				previous.add(current);
				while (!previous.isEmpty()) {
					for (int i = 0; i < subMatrix.length; i++) {
						if (subMatrix[current][i] != 0 ) {
							subMatrix[current][i] = 0;
							previous.add(current);
							current = i;
							
							break;
						}

					}
					if (!checkNext(current, subMatrix)) {
						CE.add(current);
						current = previous.pop();
					}
					

				}
				int size = CE.size();
				for (int i = 0; i <size; i++) {
					System.out.print( " "+CE.pop());
					
				}
				
			}
		}
		
	}

	
	
	
	
	
	
	
	
	
	
	public static void main(String[] args) throws NumberFormatException, IOException {
		Graph graph = new DeGraph() ;

//		graph.loadGraph("test3.txt");
//		graph.loadGraph("luongphan.txt");
		if (graph.loadGraph("cohuong.txt") == true) {
			
			graph.printMatrix();
			System.out.println("Đồ thị có hợp lí ko ? " + graph.checkValid());
			
			graph.checkUnGraph();  // Kiểm tra đồ thị có hướng ko ?
			
			System.out.println("Tổng bậc của đỉnh đã cho là : " + graph.deg(3));
			
			System.out.println("Tổng bậc của đồ thị là : " + graph.sumDeg());
			
			System.out.println("Tổng cạnh của đồ thị : " + graph.numEdges());
			
			System.out.println("BFS : " + Arrays.toString(graph.BFSGraph()));

			System.out.println("DFS : " + Arrays.toString(graph.DFSGraph()));
			
			System.out.println("BFS input vex : " + Arrays.toString(graph.BFSGraph(2)));
			
			System.out.println("DFS input vex : " + Arrays.toString(graph.DFSGraph(2)));
			
			System.out.println("checkConnect : " + graph.checkConnectForDeGraph());
			
			
			System.out.println("countConnect : " + graph.countConnect());
			
			System.out.print("Các đỉnh liên thông là 			 ");		graph.diTimCacDinhLienThong();
			
			System.out.print("Kiểm tra tính liên thông bằng thuật toán BFS thì ");		graph.isConnected();
	
			System.out.print("Đường đi từ A đến B là : ");			graph.findPathTwoVexs(3, 0);
	
			System.out.println("Kiểm tra tính lưỡng phân  : " + graph.checkBipartiteGraph());  
			
			System.out.print("Kiểm tra đồ thị có Euler không ? : ");		graph.checkEuler();
			
			System.out.println("Kiểm tra đồ thị có chu trình Euler không ? : " + graph.isEulerGraph());		
			
			System.out.println("Kiểm tra đồ thị có đường đi Euler không ? : " + graph.isHalfEulerGraph());		
			
			System.out.print("Chu trình Euler là : " ); graph.findEulerCycle()	;	
			
			System.out.print("\nĐường đi Euler là : " ); graph.findEulerPath()	;	
			
		}
		
 

}

	
	}
