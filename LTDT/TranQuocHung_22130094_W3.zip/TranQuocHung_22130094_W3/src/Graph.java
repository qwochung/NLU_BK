import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Queue;
import java.util.Stack;
import java.util.TreeMap;

public abstract class Graph {
	int peak;
	public int[][] matrix;
	boolean[] daTham;

//	Viết phương thức đọc ma trận kề từ một filetest.txt
	public boolean loadGraph(String pathFile) throws NumberFormatException, IOException {
		FileReader file = new FileReader(pathFile);
		try (BufferedReader bufferedReader = new BufferedReader(file)) {
			peak = Integer.valueOf(bufferedReader.readLine());
			System.out.println(peak);

			matrix = new int[peak][peak];
			int pos = 0;

			while (bufferedReader.ready()) {
				String[] line = bufferedReader.readLine().split(" ");
				int j = 0;
				for (String c : line) {
					matrix[pos][j++] = Integer.valueOf(c);
				}
				pos++;

			}
		}

		return true;

	}

//	Viết phương thức in ra ma trên kề của đồ thị
	public void printMatrix(int[][] inMatrix) {
		for (int i = 0; i < inMatrix.length; i++) {
			System.out.println();
			for (int j = 0; j < inMatrix[i].length; j++) {
				System.out.print(inMatrix[i][j] + " ");
			}
		}

	}

	public void printMatrix() {
		for (int i = 0; i < matrix.length; i++) {
			System.out.println();
			for (int j = 0; j < matrix[i].length; j++) {
				System.out.print(matrix[i][j] + " ");
			}
		}
		System.out.println();
	}

//	Viết phương thức kiểm tra đồ thị có hợp lý không (có hướng hoặc vô hướng)

	public boolean checkValid() {
		for (int i = 0; i < matrix.length; i++) {
			if (matrix[i][i] != 0) {
				return false;
			}
		}

		return true;
	}

//		Viết phương thức kiểm tra đồ thị có phải là  đồ thị vô hướng hay không
	public boolean checkUnGraph() {
		return new UnGraph(matrix).checkUnGraph() ? true : new DeGraph(matrix).checkUnGraph();
	}

//		Viết phương thức thêm một cạnh vào đồ thị

	public void addEdge(int[][] matrix, int v1, int v2) {
		matrix[v1][v2] = 1;
		matrix[v2][v1] = 1;
	}

//		Viết phương thức xóa một cạnh vào đồ thị

	public void removeEdge(int[][] matrix, int v1, int v2) {
		if (v1 > matrix.length || v2> matrix.length) {
			System.out.println("Sai cạnh");
		}
		else {
			matrix[v1][v2] = 0;
			matrix[v2][v1] = 0;
		}
		
	}

//		Viết phương tính tổng bậc của mỗi đỉnh
	public int deg(int v) {
		return Arrays.stream(matrix[v-1]).sum();
	}

	
	
//	Viết phương tính tổng bậc của đồ thị
	public int sumDeg (int v) {
		return checkUnGraph()? new UnGraph(matrix).sumDeg() : new DeGraph(matrix).sumDeg();
		}
	// Hỏi lại !!!
	
	
	
	
//	Câu 10: (1) Viết phương tính tổng số cạnh của đồ thị
	public int numEdges(){
		return sumDeg(peak)/2;
	}
	
	
	
//	Câu 11: (1) Viết phương thức kiểm tra đồ thị có liên thông hay không
	public boolean checkConnect(){
		 daTham= new boolean[matrix.length];
		daTham[0] = true;
		int count = 1;
		for (int i = 0; i < daTham.length; i++) {
			if (daTham[i]) {
				for (int j = 0; j < daTham.length; j++) {
					if (matrix[i][j] != 0 && !daTham[j]) {
						daTham[j] = true;
						count++;
					}
					if (count== matrix.length) {
						return true;
					}
				}
			}
			 
		}
		return false;
	}
	
	
	
	public boolean checkConnect(int startVex){
		daTham= new boolean[matrix.length];
		daTham[startVex] = true;
		int count = 1;
		for (int i = startVex; i < daTham.length; i++) {
			if (daTham[i]) {
				for (int j = 0; j < daTham.length; j++) {
					if (matrix[i][j] != 0 && !daTham[j]) {
						daTham[j] = true;
						count++;
					}
					if (count== matrix.length) {
						return true;
					}
				}
			}
			
		}
		return false;
	}
	
	
	
	
//	Tính số thành phần liên thông
	public int  countConnect() {
		int count = 0;
		daTham = new boolean[matrix.length];
		for (int i = 0; i < daTham.length; i++) {
			if (!daTham[i]) {
				count++;
				checkConnect(i);
			}
			
		}
		
		return count;
	}
	
	
	
	
//	Câu 12: (2) Viết phương thức xét tính liên thông của đồ thị: số thành phần liên thông, liệt kê các
//	đỉnh thuộc từng thành phần liên thông nếu có?
	public void diTimCacDinhLienThong(){
		Map<Integer, List<Integer>> resultMap  = new TreeMap<Integer, List<Integer>>();
		int count =0;
		
		daTham = new boolean[matrix.length];
		for (int i = 0; i < daTham.length; i++) {
			if (!daTham[i]) {
				count++;
				checkConnect(i);
			}
			List<Integer> list = new ArrayList<Integer>();
			List<Integer> subList = new ArrayList<Integer>();
			for (int j = 0; j < daTham.length; j++) {
				if (!list.contains(j) && daTham[j]) {
					subList.add(j);
				}
				
				if (daTham[j]) {
					list.add(j);
				}
			}
			resultMap.put(count, new ArrayList<>(subList));
			subList.clear();
			
		}
		
		 for (Map.Entry<Integer, List<Integer>> entry : resultMap.entrySet()) {
	            System.out.print(entry.getKey() + " : ");
	            System.out.println(entry.getValue());
	            
	            
	        }
		
		return ;
	}
	
	
	
	
	
	public void xetTinhLienThong(){
	}
	
	
	
//	Câu 13: (2) Viết phương thức dùng giải thuật BFS duyệt đồ thị G,
	public int[]  BFSGraph(){
		Queue<Integer> open = new LinkedList<Integer>();
		List<Integer> close = new ArrayList<Integer>();
		List<Integer> next = new ArrayList<Integer>();
		open.add(0);
		while (!open.isEmpty()) {
			int current = open.poll();
			for (int i = 0 ; i < matrix.length; i++) {
				if (!close.contains(current)) {
					close.add(current);
				}
				if ((matrix[current][i] != 0 || matrix[i][current] !=0 ) && !close.contains(i)) {
					
					next.add(i);
				}
				
			}
			Collections.sort(next);
			next.forEach(x -> {
				if (!close.contains(x)) {
					open.add(x);
					
				}
			});
			
			next.clear();
		}
		

		
//		return close.stream().mapToInt(x -> x).toArray();
		return close.stream().mapToInt(Integer :: intValue).toArray();
		
		 
	}
	
	
	public int[] BFSGraph(int startVex) {
		Queue<Integer> open = new LinkedList<Integer>();
		List<Integer> close = new ArrayList<Integer>();
		List<Integer> next = new ArrayList<Integer>();
		
		open.add(startVex);
		while (!open.isEmpty()) {
			int current = open.poll();
			for (int i = 0 ; i < matrix.length; i++) {
				if (!close.contains(current)) {
					close.add(current);
				}
				if ((matrix[current][i] != 0 || matrix[i][current] !=0 ) && !close.contains(i)) {
					
					next.add(i);
				}
				
			}
			Collections.sort(next);
			next.forEach(x -> {
				if (!close.contains(x)) {
					open.add(x);
					
				}
			});
			
			next.clear();
		}
		
		
		return close.stream().mapToInt(x -> x).toArray();
		
	}
	
	
	
//	Câu 14: (2) Viết phương thức dùng giải thuật DFS duyệt đồ thị G,
	public int[] DFSGraph() {
		
		Stack<Integer> open = new Stack<Integer>();
		List<Integer> close = new ArrayList<Integer>();
		List<Integer> next = new ArrayList<Integer>();
		open.add(0);
		while (!open.isEmpty()) {
			int current = open.pop();
			for (int i = 0 ; i < matrix.length; i++) {
				if (!close.contains(current)) {
					close.add(current);
				}
				if ((matrix[current][i] != 0 || matrix[i][current] !=0 ) && !close.contains(i)) {
					
					next.add(i);
				}
				
			}
			Collections.sort(next);
			next.forEach(x -> {
				if (!close.contains(x)) {
					open.add(x);
					
				}
			});
			
			next.clear();
		}
		

		
//		return close.stream().mapToInt(x -> x).toArray();
		return close.stream().mapToInt(Integer :: intValue).toArray();
	}
	
	
	
	
	
	public int[] DFSGraph( int startVex) {
		Stack<Integer> open = new Stack<Integer>();
		List<Integer> close = new ArrayList<Integer>();
		List<Integer> next = new ArrayList<Integer>();
		open.add(startVex);
		while (!open.isEmpty()) {
			int current = open.pop();
			for (int i = 0 ; i < matrix.length; i++) {
				if (!close.contains(current)) {
					close.add(current);
				}
				if ((matrix[current][i] != 0 || matrix[i][current] !=0 ) && !close.contains(i)) {
					
					next.add(i);
				}
				
			}
			Collections.sort(next);
			next.forEach(x -> {
				if (!close.contains(x)) {
					open.add(x);
					
				}
			});
			
			next.clear();
		}
		

		
//		return close.stream().mapToInt(x -> x).toArray();
		return close.stream().mapToInt(Integer :: intValue).toArray();
	}
	
	
	
	
	
	
	
	public static void main(String[] args) throws NumberFormatException, IOException {
		Graph graph = new Graph() {
		};

		graph.loadGraph("test3.txt");
		graph.printMatrix();
		System.out.println("Đồ thị có hợp lí ko ? " + graph.checkValid());
		graph.checkUnGraph();
		System.out.println("Tổng bậc của mỗi đỉnh  : "+  graph.deg(3));
		System.out.println("Tổng bậc của đồ thị : "+graph.sumDeg(3));
		System.out.println( "Tổng cạnh của đồ thị : "+graph.numEdges());
		System.out.println("BFS : "+Arrays.toString(graph.BFSGraph()));
		System.out.println("DFS : "+Arrays.toString(graph.DFSGraph()));
		System.out.println("BFS input vex : "+Arrays.toString(graph.BFSGraph(2)));
		System.out.println("DFS input vex : "+Arrays.toString(graph.DFSGraph(2)));
		System.out.println("checkConnect : "+graph.checkConnect());
		System.out.println("countConnect : "+graph.countConnect());
		graph.diTimCacDinhLienThong();
		

//		int [][] matrix = {{1,1,0,1}, {0,1,0,1}, {0,0,1,0} ,{0,1,0,1}	};
//		System.out.println("\n\nMatrix Input: ");
//		graph.printMatrix(matrix );

	}
}
