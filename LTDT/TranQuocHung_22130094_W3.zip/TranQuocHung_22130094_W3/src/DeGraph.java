
public class DeGraph {
	int [][] matrix ;

	public DeGraph(int[][] matrix) {
		super();
		this.matrix = matrix;
	}
	
	public boolean checkUnGraph() {
		for (int i = 0; i < matrix.length; i++) {
			for (int j = 0; j < matrix.length; j++) {
				if (i==j ) {
					break;
				}
			
				if (matrix[i][j] == matrix[j][i]) {
					System.out.println("Không phải đồ thị vô hướng.");
					return false;
				}
				
			
			}
		}
		System.out.println("Đồ thị có hướng.");
		return true;
		
	}

	public int sumDeg() {
		// TODO Auto-generated method stub
		return 0;
	}
}
