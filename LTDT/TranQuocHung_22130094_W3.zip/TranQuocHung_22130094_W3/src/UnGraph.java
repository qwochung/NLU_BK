import java.util.Arrays;

public class UnGraph extends Graph {
	int [][] matrix ;

	public UnGraph(int[][] matrix) {
		super();
		this.matrix = matrix;
	}
	@Override
	public boolean checkUnGraph() {
		for (int i = 0; i < matrix.length; i++) {
			for (int j = 0; j < matrix.length; j++) {
				if (i==j ) {
					break;
				}
			
				if (matrix[i][j] != matrix[j][i]) {
					System.out.println("Không phải đồ thị vô hướng.");
					return false;
				}
				
			
			}
		}
		System.out.println("Đồ thị vô hướng.");
		return true;
		
	}
	public int sumDeg() {
		int resutt = 0;
		for (int[] is : matrix) {
			resutt+=  Arrays.stream(is).sum();
		}
		return resutt;
	}
	
}
